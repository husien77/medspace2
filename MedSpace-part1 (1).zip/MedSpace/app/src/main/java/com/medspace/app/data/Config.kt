package com.medspace.app.data

/**
 * ضع هنا بيانات مشروعك من Supabase (Project Settings → API).
 * مفتاح anon عام بطبيعته ومحمي بقواعد الأمان في قاعدة البيانات.
 * لا تضع هنا أبدًا مفتاح service_role.
 */
object Config {
    const val SUPABASE_URL = "https://ewqizhvqxxifewddthoj.supabase.co"
    const val SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImV3cWl6aHZxeHhpZmV3ZGR0aG9qIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTM5NzE1NjQsImV4cCI6MjEwOTU0NzU2NH0.snjPCOgcHakrboA7_XLss9EQVNQDvuUhVRChuIXhWG8"
}
